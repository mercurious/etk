# ==========================================================
# ETK WINDOWS HOST CONFIG  (mirror of scripts/env.sh)
# ==========================================================
# These values MUST match your bash scripts/env.sh. This file is the
# ONLY place the Windows port duplicates configuration — everything
# that runs on the rig is read straight out of install.sh / uninstall.sh
# at runtime, so there is no second copy of the Sentry to keep in sync.
#
# Fill each value from the matching variable in scripts/env.sh.
# Anything marked  <<< VERIFY  is a best guess from the repo and should
# be confirmed against your env.sh before you trust an install.
# ==========================================================

# --- CONNECTION -------------------------------------------------------
# Same as RIG_SSH in env.sh, e.g. "root@192.168.1.50"
$RigSsh = "root@192.168.1.50"            # <<< EDIT to match RIG_SSH

# --- CORE PATHS (on the rig) -----------------------------------------
# ETK_ROOT in env.sh. The Sentry sources env.sh from here, so it must
# match exactly. From the repo the Sentry uses:
#   /storage/games-internal/roms/etk
$EtkRoot = "/storage/games-internal/roms/etk"   # <<< VERIFY against ETK_ROOT

# CHIPSET in env.sh (used to build the vault path). e.g. "SM8250"
$Chipset = "SM8250"                      # <<< VERIFY against CHIPSET

# ID_FILE in env.sh — file on the rig holding the active game ID.
$IdFile = "$EtkRoot/active_id.txt"       # <<< VERIFY against ID_FILE

# PKG_STAGING_DIR in env.sh — the .pkg/.rap drop folder.
$PkgStaging = "/storage/roms/etk/pkg_install_drop"   # <<< VERIFY against PKG_STAGING_DIR

# --- RPCS3 PATHS (provisioned in install Step 1) ---------------------
$Rpcs3CustomConfigs = "/storage/.config/rpcs3/custom_configs"  # <<< VERIFY RPCS3_CUSTOM_CONFIGS
$Rpcs3GameDir       = "/storage/.config/rpcs3/dev_hdd0/game"    # <<< VERIFY RPCS3_GAME_DIR
$Rpcs3ExdataDir     = "/storage/.config/rpcs3/dev_hdd0/home/00000001/exdata" # <<< VERIFY RPCS3_EXDATA_DIR
$Ps3LauncherDir     = "/storage/roms/ps3"                        # <<< VERIFY PS3_LAUNCHER_DIR

# --- BEHAVIOUR TOGGLES ------------------------------------------------
# "1" = verbose scp (-v). Anything else = quiet (-q). Mirrors ETK_VERBOSE.
$EtkVerbose = "0"

# "1" = force legacy SCP wire protocol (-O). Set this to "1" if scp fails
# with "subsystem request failed" / sftp errors against the rig's SSH
# server (newer OpenSSH scp defaults to SFTP; some embedded servers need
# the old protocol). Harmless to leave at "0" unless you hit that error.
$EtkScpLegacy = "0"
