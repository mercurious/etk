#requires -Version 5.1
# ==========================================================
# ETK WINDOWS HOST INSTALLER  (no-vault port of install.sh)
# ==========================================================
# Mirrors install.sh step-for-step EXCEPT:
#   - Step 2 (vault PULL rig->host)  : SKIPPED (no host vault on Windows)
#   - Step 4 (vault PUSH host->rig)  : SKIPPED
# The rig still vaults shaders locally; only the host-side backup is gone.
# To protect a vault on Windows, copy <ETK_ROOT>/vault off the device over
# SMB before reflashing — see WINDOWS_HOST_README.md.
#
# The Sentry, systemd unit, PKG drop README, and mako style are read
# verbatim from install.sh at runtime (Get-Heredoc), so install.sh stays
# the single source of truth for everything that runs on the rig.
#
# Run from the repo root:
#   powershell -ExecutionPolicy Bypass -File .\etk-install.ps1
# ==========================================================

$ErrorActionPreference = "Stop"
. "$PSScriptRoot\etk-env.ps1"
. "$PSScriptRoot\etk-common.ps1"

$InstallSh   = Join-Path $PSScriptRoot "install.sh"
$RepoRoot    = $PSScriptRoot
$TOTAL       = 6

Write-Host ""
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  ETK WINDOWS FLASHER  (no-vault)" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host ""

Assert-Tooling
Assert-RigConnection

# ==========================================================
# STEP 0: PROBE & QUIESCE  (install.sh Step 0)
# Kill ETK workers before file ops. Resolve the rig game ID purely to
# provision that game's vault dir; the Sentry creates per-game dirs on
# demand anyway, so the NPUA80075 fallback is fine when idle.
# ==========================================================
Write-Step 0 $TOTAL "PROBING & QUIESCING REMOTE RIG..."
Invoke-Rig "pkill -f vault_d.sh; pkill -f thermal_d.sh; pkill -f mango_bridge.sh; pkill -f input_d.py" 2>$null | Out-Null
Start-Sleep -Seconds 1

$RigId = (Invoke-Rig "cat $IdFile 2>/dev/null || pgrep -f rpcs3 | xargs -I{} cat /proc/{}/cmdline /proc/{}/environ 2>/dev/null | tr '\0' '\n' | grep -oE '[A-Z]{4}[0-9]{5}' | head -n 1")
$RigId = ("$RigId").Trim()
switch ($RigId) {
    ""           { $TargetId = "NPUA80075" }
    "IDLE"       { $TargetId = "NPUA80075" }
    "UNKNOWN_ID" { $TargetId = "NPUA80075" }
    default      { $TargetId = $RigId }
}
$VaultDir = "$EtkRoot/vault/$Chipset/$TargetId/shaders"
Write-Note "RIG ID   : $TargetId"
Write-Note "VAULT DIR: $VaultDir"

# ==========================================================
# STEP 1: PROVISION RIG DIRECTORIES  (install.sh Step 1)
# ==========================================================
Write-Step 1 $TOTAL "PROVISIONING RIG DIRECTORIES..."
$dirs = @(
    $VaultDir, "$EtkRoot/bin", "$EtkRoot/scripts", "$EtkRoot/vault",
    "$EtkRoot/logs", "$EtkRoot/config", $PkgStaging,
    "/storage/.config/custom_scripts", "/storage/.config/system.d",
    "/storage/.config/modules", "/storage/.config/MangoHud",
    $Rpcs3CustomConfigs, $Rpcs3GameDir, $Rpcs3ExdataDir, $Ps3LauncherDir
)
$mkdirCmd = "mkdir -p " + (($dirs | ForEach-Object { "'$_'" }) -join " ")
Invoke-Rig $mkdirCmd | Out-Null
Write-Ok "Directories provisioned."

# PKG drop-folder README (verbatim from install.sh PKGREADME heredoc)
$pkgReadme = Get-Heredoc -Path $InstallSh -Marker "PKGREADME"
Send-Text -Content $pkgReadme -RemotePath "$PkgStaging/README.txt"
Write-Ok "PKG drop-folder README written."

# ETK mako notification style (verbatim ETKMAKO block; host-var-free)
$mako = Get-Heredoc -Path $InstallSh -Marker "ETKMAKO"
$makoOut = Invoke-RigBash -Script $mako
if ($makoOut) { $makoOut | ForEach-Object { Write-Note $_ } }

# ==========================================================
# STEP 2: VAULT PULL  ->  SKIPPED on Windows (no host vault)
# ==========================================================
Write-Step 2 $TOTAL "SAFEGUARD HARVEST (vault pull) — SKIPPED on Windows host."
Write-Note "No host-side vault backup on Windows. Copy <ETK_ROOT>/vault over SMB if you want to shield it."

# ==========================================================
# STEP 3: DEPLOY SCRIPTS, DAEMONS & OVERLAYS  (install.sh Step 3)
# --delete is replicated by Push-Dir -Mirror (remote tree removed first).
# ==========================================================
Write-Step 3 $TOTAL "DEPLOYING GUARDIAN DAEMONS & SCRIPTS..."
Push-Dir -LocalDir (Join-Path $RepoRoot "bin")     -RemoteParent $EtkRoot -Mirror
Push-Dir -LocalDir (Join-Path $RepoRoot "scripts") -RemoteParent $EtkRoot -Mirror
$mangoLocal = Join-Path $RepoRoot "config\MangoHud.conf"
if (Test-Path -LiteralPath $mangoLocal) {
    Send-File -LocalPath $mangoLocal -RemotePath "/storage/.config/MangoHud/MangoHud.conf"
} else {
    Write-Warn "config\MangoHud.conf not found locally — skipping overlay push (verify the filename)."
}
Invoke-Rig "chmod +x $EtkRoot/bin/* $EtkRoot/scripts/* 2>/dev/null; true" | Out-Null

# WINDOWS-SPECIFIC: strip any CRLF from shell scripts that a Windows clone
# may have introduced. install.sh relies on a Linux/Mac checkout being LF;
# here we normalise on the rig so the daemons actually run. (See the
# .gitattributes recommendation in WINDOWS_HOST_README.md.)
$crlfFix = @'
for f in __ETKROOT__/bin/*.sh __ETKROOT__/scripts/*.sh; do
  [ -f "$f" ] && sed -i 's/\r$//' "$f"
done
true
'@
Invoke-RigTemplate -Template $crlfFix | Out-Null
Write-Ok "Daemons + scripts deployed (CRLF normalised)."

# ==========================================================
# STEP 4: VAULT PUSH  ->  SKIPPED on Windows (no host vault)
# ==========================================================
Write-Step 4 $TOTAL "RESTORE BANKED SHADERS (vault push) — SKIPPED on Windows host."

# ==========================================================
# STEP 5: DEPLOY ETK PITSTOP ROCKNIX INTERFACE  (install.sh Step 5)
# ==========================================================
Write-Step 5 $TOTAL "DEPLOYING ETK PITSTOP ROCKNIX INTERFACE..."

# Push config payload (pitstop_fields.json, crash_signatures.json,
# etk_template.yml, etk_pitstop.svg, etk_pitstop.sh master copy, ...).
Push-Dir -LocalDir (Join-Path $RepoRoot "config") -RemoteParent $EtkRoot

# Sanitise + arm the master launcher copy in config/
$fixMaster = @'
sed -i 's/\r$//' __ETKROOT__/config/etk_pitstop.sh
chmod +x __ETKROOT__/config/etk_pitstop.sh
'@
Invoke-RigTemplate -Template $fixMaster | Out-Null

# Deploy launcher to the volatile modules dir for immediate use
Send-File -LocalPath (Join-Path $RepoRoot "config\etk_pitstop.sh") `
          -RemotePath "/storage/.config/modules/etk_pitstop.sh"
Invoke-Rig "sed -i 's/\r$//' /storage/.config/modules/etk_pitstop.sh && chmod +x /storage/.config/modules/etk_pitstop.sh && sync" | Out-Null

# Verify the launcher landed and is executable
$check = (Invoke-Rig "[ -x /storage/.config/modules/etk_pitstop.sh ] && echo OK || echo MISSING").Trim()
if ($check -ne "OK") {
    Write-ErrLine "Launcher missing or lacks +x — aborting."
    exit 1
}
Write-Ok "Launcher verified and locked to disk."

# Register the Tools-menu app (idempotent injector)
Write-Note "Registering ETK Pitstop in the Tools menu..."
Invoke-Rig "python3 $EtkRoot/bin/etk_modules_inject.py" | Out-Null
$glCount = (Invoke-Rig "grep -c '>ETK Pitstop<' /storage/.config/modules/gamelist.xml 2>/dev/null || echo 0").Trim()
if (($glCount -as [int]) -ge 1) {
    Write-Ok "ETK Pitstop registered as a Tools-menu app."
} else {
    Write-Warn "Tools-menu entry not confirmed — the Sentry will re-inject it on boot."
}

# ==========================================================
# STEP 6: WRITE & RESTART THE SENTRY  (install.sh Step 6)
# SENTRY and SVC bodies are pulled verbatim from install.sh.
# ==========================================================
Write-Step 6 $TOTAL "DEPLOYING ROCKNIX-NATIVE SYSTEMD SENTRY..."
$sentry = Get-Heredoc -Path $InstallSh -Marker "SENTRY"
$svc    = Get-Heredoc -Path $InstallSh -Marker "SVC"

Invoke-Rig "mkdir -p /storage/.config/custom_scripts /storage/.config/system.d" | Out-Null
Send-Text -Content $sentry -RemotePath "/storage/.config/custom_scripts/01-etk-sentry.sh" -Executable
Send-Text -Content $svc    -RemotePath "/storage/.config/system.d/etk.service"

Invoke-Rig "systemctl daemon-reload; systemctl enable /storage/.config/system.d/etk.service 2>/dev/null; systemctl restart etk.service" | Out-Null
Start-Sleep -Seconds 2
$active = (Invoke-Rig "systemctl is-active etk.service 2>/dev/null || true").Trim()
if ($active -eq "active") { Write-Ok "Sentry service is active." }
else { Write-Warn "Sentry not confirmed active (reported '$active'). Check: ssh $RigSsh 'systemctl status etk.service'" }

Write-Host ""
Write-Host ">>> DEPLOYMENT COMPLETE. REBOOT THE DEVICE TO ACTIVATE ETK PITSTOP IN ROCKNIX TOOLS." -ForegroundColor Green
Write-Note "(EmulationStation reads the Tools gamelist at startup, so the polished"
Write-Note " ETK Pitstop entry appears after a reboot — Update Gamelists does not refresh it.)"
Write-Note "Confirm sentry health: ssh $RigSsh 'systemctl status etk.service'"
Write-Host ""
